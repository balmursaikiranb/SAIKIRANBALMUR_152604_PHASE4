package com.cg.paymentwalletspring.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.paymentwalletspring.dto.Customer;
import com.cg.paymentwalletspring.dto.Wallet;
import com.cg.paymentwalletspring.exception.PaymentWalletException;
import com.cg.paymentwalletspring.service.PaymentWalletService;


@RestController
public class PaymentWalletController {
@Autowired
private PaymentWalletService service;
	
	@RequestMapping(value="/regster",method=RequestMethod.POST)
	public Customer registerCustomer(@RequestBody Customer customer) throws PaymentWalletException
	{
		
		return service.registerCustomer(customer);
		
	}
	@RequestMapping(value="/deposit/{phone}/{amount}",method=RequestMethod.PUT)
	public Customer deposit(@PathVariable String phone,@PathVariable BigDecimal amount) throws PaymentWalletException
	{
		return service.depositMoney(phone,amount);
		
	}
	@RequestMapping(value="/withdraw/{phone}/{amount}",method=RequestMethod.PUT)
	public Customer withdraw(@PathVariable String phone,@PathVariable BigDecimal amount) throws PaymentWalletException
	{
		return service.withdrawMoney(phone,amount);
		
	}
	@RequestMapping(value="/fundtransfer/{sourcephone}/{targetphone}/{amount}",method=RequestMethod.PUT)
	public Customer fundTransfer(@PathVariable String sourcephone,@PathVariable String targetphone,@PathVariable BigDecimal amount) throws PaymentWalletException
	{
		return service.fundTransfer(sourcephone,targetphone,amount);
		
	}
	@RequestMapping(value="/showbalance/{phone}",method=RequestMethod.GET)
	public Customer showBalance(@PathVariable String phone) throws PaymentWalletException
	{
		return service.showBalance(phone);
		
	}
	@RequestMapping(value="/statement/{phone}",method=RequestMethod.GET)
	public List<String> statement(@PathVariable String phone) throws PaymentWalletException
	{
		 String string=service.printTransaction(phone);
		 Scanner sc=new Scanner(string).useDelimiter("zzz");
		 String str=null;
		 List<String> list=new ArrayList<>();
		 while(sc.hasNext())
		 {
			 list.add(sc.next());
			
		 }
		return list;
		
		
	}
	@RequestMapping(value="/login/{phone}/{password}",method=RequestMethod.GET)
	public boolean login(@PathVariable String phone,@PathVariable String password) throws PaymentWalletException
	{
		return service.checkLogin(phone,password);
		
	}
}
